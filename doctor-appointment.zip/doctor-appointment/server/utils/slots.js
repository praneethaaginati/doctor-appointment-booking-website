// 30-minute slots, 09:00 - 17:00, lunch break 13:00 - 14:00
const SLOTS = [];
for (let h = 9; h < 17; h++) {
  if (h === 13) continue;
  SLOTS.push(`${String(h).padStart(2, '0')}:00`);
  SLOTS.push(`${String(h).padStart(2, '0')}:30`);
}
module.exports = SLOTS;
