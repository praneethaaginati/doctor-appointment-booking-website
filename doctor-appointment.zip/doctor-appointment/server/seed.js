require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Doctor = require('./models/Doctor');
const Appointment = require('./models/Appointment');

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await Promise.all([User.deleteMany(), Doctor.deleteMany(), Appointment.deleteMany()]);

  await User.create([
    { name: 'Admin', email: 'admin@hospital.com', password: await bcrypt.hash('admin123', 10), role: 'admin' },
    { name: 'Demo Patient', email: 'patient@demo.com', password: await bcrypt.hash('patient123', 10), phone: '9999999999' },
  ]);

  await Doctor.create([
    { name: 'Dr. Ananya Rao', department: 'Cardiology', experience: 12, fee: 800, bio: 'Heart rhythm disorders and preventive cardiology.' },
    { name: 'Dr. Vikram Shah', department: 'Orthopedics', experience: 15, fee: 700, bio: 'Joint replacement and sports injuries.' },
    { name: 'Dr. Meera Iyer', department: 'Pediatrics', experience: 8, fee: 500, bio: 'Child health, vaccination and growth.' },
    { name: 'Dr. Rahul Menon', department: 'Dermatology', experience: 6, fee: 600, bio: 'Skin, hair and allergy care.' },
    { name: 'Dr. Sana Khan', department: 'Neurology', experience: 10, fee: 900, bio: 'Migraine, epilepsy and stroke recovery.' },
    { name: 'Dr. Arjun Nair', department: 'General Medicine', experience: 9, fee: 400, bio: 'Primary care and chronic condition management.' },
  ]);

  console.log('Seeded. Admin: admin@hospital.com / admin123 | Patient: patient@demo.com / patient123');
  process.exit(0);
})();
