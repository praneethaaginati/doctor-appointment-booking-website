const router = require('express').Router();
const Doctor = require('../models/Doctor');
const Appointment = require('../models/Appointment');
const SLOTS = require('../utils/slots');
const { protect, adminOnly } = require('../middleware/auth');

// SEARCH doctors: /api/doctors?q=name&department=Cardiology
router.get('/', async (req, res, next) => {
  try {
    const { q, department } = req.query;
    const filter = {};
    if (q) filter.name = { $regex: q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' };
    if (department) filter.department = department;
    res.json(await Doctor.find(filter).sort({ name: 1 }));
  } catch (e) { next(e); }
});

router.get('/departments', async (req, res, next) => {
  try { res.json((await Doctor.distinct('department')).sort()); } catch (e) { next(e); }
});

// Time slots for a doctor on a date (marks booked ones)
router.get('/:id/slots', async (req, res, next) => {
  try {
    const { date, exclude } = req.query;
    if (!date) return res.status(400).json({ message: 'Date is required' });
    const filter = { doctor: req.params.id, date, status: 'booked' };
    if (exclude) filter._id = { $ne: exclude };
    const taken = (await Appointment.find(filter)).map((a) => a.time);
    res.json(SLOTS.map((time) => ({ time, available: !taken.includes(time) })));
  } catch (e) { next(e); }
});

router.get('/:id', async (req, res, next) => {
  try {
    const doc = await Doctor.findById(req.params.id);
    if (!doc) return res.status(404).json({ message: 'Doctor not found' });
    res.json(doc);
  } catch (e) { next(e); }
});

// ADMIN: create / update / delete
router.post('/', protect, adminOnly, async (req, res, next) => {
  try { res.status(201).json(await Doctor.create(req.body)); } catch (e) { next(e); }
});

router.put('/:id', protect, adminOnly, async (req, res, next) => {
  try {
    const doc = await Doctor.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!doc) return res.status(404).json({ message: 'Doctor not found' });
    res.json(doc);
  } catch (e) { next(e); }
});

router.delete('/:id', protect, adminOnly, async (req, res, next) => {
  try {
    await Doctor.findByIdAndDelete(req.params.id);
    await Appointment.updateMany({ doctor: req.params.id, status: 'booked' }, { status: 'cancelled' });
    res.json({ message: 'Doctor removed' });
  } catch (e) { next(e); }
});

module.exports = router;
