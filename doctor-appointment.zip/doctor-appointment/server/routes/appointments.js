const router = require('express').Router();
const Appointment = require('../models/Appointment');
const Doctor = require('../models/Doctor');
const SLOTS = require('../utils/slots');
const { protect, adminOnly } = require('../middleware/auth');

const today = () => new Date().toISOString().slice(0, 10);
const taken = () => Object.assign(new Error('That slot was just taken. Pick another time'), { status: 409 });

async function validateSlot({ doctor, date, time }, excludeId) {
  if (!SLOTS.includes(time)) throw Object.assign(new Error('Choose a valid time slot'), { status: 400 });
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date < today())
    throw Object.assign(new Error('Choose today or a future date'), { status: 400 });
  const filter = { doctor, date, time, status: 'booked' };
  if (excludeId) filter._id = { $ne: excludeId };
  if (await Appointment.findOne(filter)) throw taken();
}

const populate = (q) => q.populate('doctor', 'name department fee').populate('patient', 'name email phone');

// CREATE (book)
router.post('/', protect, async (req, res, next) => {
  try {
    if (req.user.role !== 'patient') return res.status(403).json({ message: 'Only patients can book appointments' });
    const { doctor, date, time, reason } = req.body;
    const doc = await Doctor.findById(doctor);
    if (!doc) return res.status(404).json({ message: 'Doctor not found' });
    await validateSlot({ doctor, date, time });
    const appt = await Appointment.create({
      patient: req.user._id, doctor, department: doc.department, date, time, reason,
    });
    res.status(201).json(await populate(Appointment.findById(appt._id)));
  } catch (e) {
    next(e.code === 11000 ? taken() : e);
  }
});

// READ: patients see their own, admin sees all
router.get('/', protect, async (req, res, next) => {
  try {
    const filter = req.user.role === 'admin' ? {} : { patient: req.user._id };
    if (req.query.status) filter.status = req.query.status;
    res.json(await populate(Appointment.find(filter).sort({ date: 1, time: 1 })));
  } catch (e) { next(e); }
});

// UPDATE: reschedule / cancel (owner) or change status (admin)
router.put('/:id', protect, async (req, res, next) => {
  try {
    const appt = await Appointment.findById(req.params.id);
    if (!appt) return res.status(404).json({ message: 'Appointment not found' });
    const isAdmin = req.user.role === 'admin';
    if (!isAdmin && String(appt.patient) !== String(req.user._id))
      return res.status(403).json({ message: 'Not your appointment' });

    const { date, time, reason, status } = req.body;

    if (status) {
      if (!isAdmin && status !== 'cancelled')
        return res.status(403).json({ message: 'You can only cancel your appointment' });
      appt.status = status;
    }
    if (status === 'booked') {
      // re-activating: make sure the slot is still free
      await validateSlot({ doctor: appt.doctor, date: appt.date, time: appt.time }, appt._id).catch((e) => {
        if (e.status === 409) throw e; // past dates are fine to re-open for admin
      });
    }
    if ((date || time) && appt.status === 'booked') {
      const target = { doctor: appt.doctor, date: date || appt.date, time: time || appt.time };
      await validateSlot(target, appt._id);
      appt.date = target.date;
      appt.time = target.time;
    }
    if (reason !== undefined) appt.reason = reason;
    await appt.save();
    res.json(await populate(Appointment.findById(appt._id)));
  } catch (e) {
    next(e.code === 11000 ? taken() : e);
  }
});

// DELETE (admin)
router.delete('/:id', protect, adminOnly, async (req, res, next) => {
  try {
    await Appointment.findByIdAndDelete(req.params.id);
    res.json({ message: 'Appointment deleted' });
  } catch (e) { next(e); }
});

module.exports = router;
