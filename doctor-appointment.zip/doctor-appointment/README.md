# CareSlot - Doctor Appointment Booking (MERN)

Search doctors, book / reschedule / cancel appointments. Admin manages doctors and all appointments.

## Prerequisites
- Node.js 18+
- MongoDB running locally (or a MongoDB Atlas URI)

## Run
```bash
# 1. Backend
cd server
npm install
# edit .env if your MongoDB URI is different
npm run seed      # creates demo admin, patient and doctors
npm run dev       # http://localhost:5000

# 2. Frontend (new terminal)
cd client
npm install
npm run dev       # http://localhost:5173
```

## Demo logins
- Admin:   admin@hospital.com / admin123
- Patient: patient@demo.com / patient123

## REST API
| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | /api/auth/register | public | Register patient |
| POST | /api/auth/login | public | Login (JWT) |
| GET | /api/auth/me | user | Current user |
| GET | /api/doctors?q=&department= | public | Search doctors |
| GET | /api/doctors/departments | public | List departments |
| GET | /api/doctors/:id/slots?date= | public | Free/booked slots |
| POST/PUT/DELETE | /api/doctors(/:id) | admin | Doctor CRUD |
| POST | /api/appointments | patient | Book |
| GET | /api/appointments | user | Own (patient) or all (admin) |
| PUT | /api/appointments/:id | owner/admin | Reschedule, cancel, change status |
| DELETE | /api/appointments/:id | admin | Delete record |

## Features
- JWT auth, bcrypt passwords, role-based access (patient / admin)
- Double-booking prevented by a MongoDB partial unique index plus server checks
- Live search and department filter
- 30-minute slots, lunch break excluded
