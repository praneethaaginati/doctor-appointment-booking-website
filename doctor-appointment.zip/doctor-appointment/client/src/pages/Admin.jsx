import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';

const empty = { name: '', department: '', experience: 0, fee: 0, bio: '' };

export default function Admin() {
  const [tab, setTab] = useState('doctors');
  const [doctors, setDoctors] = useState([]);
  const [appts, setAppts] = useState([]);
  const [form, setForm] = useState(empty);
  const [editId, setEditId] = useState(null);
  const [error, setError] = useState('');

  const loadDoctors = () => api.get('/doctors').then((r) => setDoctors(r.data));
  const loadAppts = () => api.get('/appointments').then((r) => setAppts(r.data));
  useEffect(() => { loadDoctors(); loadAppts(); }, []);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const saveDoctor = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const body = { ...form, experience: Number(form.experience), fee: Number(form.fee) };
      if (editId) await api.put(`/doctors/${editId}`, body);
      else await api.post('/doctors', body);
      setForm(empty);
      setEditId(null);
      loadDoctors();
    } catch (err) { setError(errMsg(err)); }
  };

  const editDoctor = (d) => {
    setEditId(d._id);
    setForm({ name: d.name, department: d.department, experience: d.experience, fee: d.fee, bio: d.bio });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const removeDoctor = async (d) => {
    if (!confirm(`Remove ${d.name}? Their booked appointments will be cancelled.`)) return;
    await api.delete(`/doctors/${d._id}`);
    loadDoctors(); loadAppts();
  };

  const setStatus = async (a, status) => {
    setError('');
    try { await api.put(`/appointments/${a._id}`, { status }); }
    catch (err) { setError(errMsg(err)); }
    loadAppts();
  };

  const removeAppt = async (a) => {
    if (!confirm('Delete this appointment record permanently?')) return;
    await api.delete(`/appointments/${a._id}`);
    loadAppts();
  };

  const stats = {
    doctors: doctors.length,
    booked: appts.filter((a) => a.status === 'booked').length,
    completed: appts.filter((a) => a.status === 'completed').length,
    cancelled: appts.filter((a) => a.status === 'cancelled').length,
  };

  return (
    <>
      <h1>Manage clinic</h1>
      <div className="stats">
        <div><b>{stats.doctors}</b> doctors</div>
        <div><b>{stats.booked}</b> upcoming</div>
        <div><b>{stats.completed}</b> completed</div>
        <div><b>{stats.cancelled}</b> cancelled</div>
      </div>

      <div className="tabs">
        <button className={tab === 'doctors' ? 'on' : ''} onClick={() => setTab('doctors')}>Doctors</button>
        <button className={tab === 'appts' ? 'on' : ''} onClick={() => setTab('appts')}>All appointments</button>
      </div>
      {error && <p className="error">{error}</p>}

      {tab === 'doctors' && (
        <>
          <form className="card form-grid" onSubmit={saveDoctor}>
            <h2>{editId ? 'Edit doctor' : 'Add a doctor'}</h2>
            <label>Name<input required value={form.name} onChange={set('name')} /></label>
            <label>Department<input required value={form.department} onChange={set('department')} /></label>
            <label>Experience (years)<input type="number" min="0" value={form.experience} onChange={set('experience')} /></label>
            <label>Fee (₹)<input type="number" min="0" value={form.fee} onChange={set('fee')} /></label>
            <label className="wide">Short bio<input value={form.bio} onChange={set('bio')} /></label>
            <div className="row">
              <button className="btn">{editId ? 'Save changes' : 'Add doctor'}</button>
              {editId && <button type="button" className="btn ghost" onClick={() => { setEditId(null); setForm(empty); }}>Cancel edit</button>}
            </div>
          </form>

          <div className="table-wrap">
            <table>
              <thead><tr><th>Name</th><th>Department</th><th>Experience</th><th>Fee</th><th></th></tr></thead>
              <tbody>
                {doctors.map((d) => (
                  <tr key={d._id}>
                    <td>{d.name}</td><td>{d.department}</td><td>{d.experience} yrs</td><td>₹{d.fee}</td>
                    <td className="actions">
                      <button className="btn small ghost" onClick={() => editDoctor(d)}>Edit</button>
                      <button className="btn small danger" onClick={() => removeDoctor(d)}>Remove</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {tab === 'appts' && (
        <div className="table-wrap">
          <table>
            <thead><tr><th>Patient</th><th>Doctor</th><th>Department</th><th>Date</th><th>Time</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {appts.map((a) => (
                <tr key={a._id}>
                  <td>{a.patient?.name}<br /><span className="muted small">{a.patient?.email}</span></td>
                  <td>{a.doctor?.name}</td>
                  <td>{a.department}</td>
                  <td>{a.date}</td>
                  <td>{a.time}</td>
                  <td>
                    <select value={a.status} onChange={(e) => setStatus(a, e.target.value)}>
                      <option value="booked">booked</option>
                      <option value="completed">completed</option>
                      <option value="cancelled">cancelled</option>
                    </select>
                  </td>
                  <td className="actions"><button className="btn small danger" onClick={() => removeAppt(a)}>Delete</button></td>
                </tr>
              ))}
              {appts.length === 0 && <tr><td colSpan="7" className="muted">No appointments yet.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
