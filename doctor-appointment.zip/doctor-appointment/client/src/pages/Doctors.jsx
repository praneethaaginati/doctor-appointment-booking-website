import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';
import { useAuth } from '../AuthContext';
import BookingModal from '../components/BookingModal';

export default function Doctors() {
  const { user } = useAuth();
  const nav = useNavigate();
  const [doctors, setDoctors] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [q, setQ] = useState('');
  const [department, setDepartment] = useState('');
  const [selected, setSelected] = useState(null);
  const [toast, setToast] = useState('');

  useEffect(() => { api.get('/doctors/departments').then((r) => setDepartments(r.data)); }, []);

  useEffect(() => {
    const t = setTimeout(() => {
      api.get('/doctors', { params: { q, department } }).then((r) => setDoctors(r.data));
    }, 250);
    return () => clearTimeout(t);
  }, [q, department]);

  const book = (d) => {
    if (!user) return nav('/login');
    if (user.role === 'admin') return setToast('Admins manage the clinic. Log in as a patient to book');
    setSelected(d);
  };

  return (
    <>
      <section className="hero">
        <h1>See the right doctor, at a time that works.</h1>
        <p className="muted">Search by name or department, pick a free slot, and you are booked.</p>
        <div className="filters">
          <input placeholder="Search doctor by name" value={q} onChange={(e) => setQ(e.target.value)} />
          <select value={department} onChange={(e) => setDepartment(e.target.value)}>
            <option value="">All departments</option>
            {departments.map((d) => <option key={d}>{d}</option>)}
          </select>
        </div>
      </section>

      {toast && <p className="notice" onClick={() => setToast('')}>{toast}</p>}

      {doctors.length === 0 ? (
        <p className="muted">No doctors match your search. Try another name or department.</p>
      ) : (
        <div className="grid">
          {doctors.map((d) => (
            <article className="doc" key={d._id}>
              <div className="avatar">{d.name.replace('Dr. ', '').split(' ').map((w) => w[0]).join('')}</div>
              <div>
                <h3>{d.name}</h3>
                <p className="dept">{d.department}</p>
                <p className="muted small">{d.bio}</p>
                <p className="small">{d.experience} yrs experience · Fee ₹{d.fee}</p>
              </div>
              <button className="btn" onClick={() => book(d)}>Book appointment</button>
            </article>
          ))}
        </div>
      )}

      {selected && (
        <BookingModal
          doctor={selected}
          onClose={() => setSelected(null)}
          onDone={() => { setSelected(null); nav('/appointments'); }}
        />
      )}
    </>
  );
}
