import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import BookingModal from '../components/BookingModal';

export default function Appointments() {
  const [list, setList] = useState([]);
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState('');

  const load = () => api.get('/appointments').then((r) => setList(r.data));
  useEffect(() => { load(); }, []);

  const cancel = async (a) => {
    if (!confirm(`Cancel your visit with ${a.doctor.name} on ${a.date}?`)) return;
    try { await api.put(`/appointments/${a._id}`, { status: 'cancelled' }); load(); }
    catch (e) { setError(errMsg(e)); }
  };

  return (
    <>
      <h1>My appointments</h1>
      {error && <p className="error">{error}</p>}
      {list.length === 0 ? (
        <p className="muted">You have no appointments yet. Find a doctor to book your first visit.</p>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Doctor</th><th>Department</th><th>Date</th><th>Time</th><th>Reason</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
              {list.map((a) => (
                <tr key={a._id}>
                  <td>{a.doctor?.name}</td>
                  <td>{a.department}</td>
                  <td>{a.date}</td>
                  <td>{a.time}</td>
                  <td>{a.reason || '-'}</td>
                  <td><span className={`tag ${a.status}`}>{a.status}</span></td>
                  <td className="actions">
                    {a.status === 'booked' && (
                      <>
                        <button className="btn small ghost" onClick={() => setEditing(a)}>Reschedule</button>
                        <button className="btn small danger" onClick={() => cancel(a)}>Cancel</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {editing && (
        <BookingModal appointment={editing} onClose={() => setEditing(null)} onDone={() => { setEditing(null); load(); }} />
      )}
    </>
  );
}
