import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';

const todayStr = () => new Date().toISOString().slice(0, 10);

// Used for both new bookings (doctor) and rescheduling (appointment)
export default function BookingModal({ doctor, appointment, onClose, onDone }) {
  const editing = !!appointment;
  const doc = editing ? appointment.doctor : doctor;
  const [date, setDate] = useState(editing ? appointment.date : todayStr());
  const [time, setTime] = useState(editing ? appointment.time : '');
  const [reason, setReason] = useState(editing ? appointment.reason : '');
  const [slots, setSlots] = useState([]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.get(`/doctors/${doc._id}/slots`, { params: { date, exclude: appointment?._id } })
      .then((r) => setSlots(r.data))
      .catch((e) => setError(errMsg(e)));
  }, [date]);

  const submit = async () => {
    if (!time) return setError('Pick a time slot');
    setBusy(true);
    setError('');
    try {
      if (editing) await api.put(`/appointments/${appointment._id}`, { date, time, reason });
      else await api.post('/appointments', { doctor: doc._id, date, time, reason });
      onDone();
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
    }
  };

  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h2>{editing ? 'Reschedule' : 'Book'} with {doc.name}</h2>
        <p className="muted">{doc.department}</p>

        <label>Date
          <input type="date" min={todayStr()} value={date} onChange={(e) => { setDate(e.target.value); setTime(''); }} />
        </label>

        <p className="label">Available times</p>
        <div className="slots">
          {slots.map((s) => (
            <button
              key={s.time}
              disabled={!s.available}
              className={`slot ${time === s.time ? 'on' : ''}`}
              onClick={() => setTime(s.time)}
            >
              {s.time}
            </button>
          ))}
        </div>

        <label>Reason for visit
          <textarea rows={2} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Fever, check-up, follow-up…" />
        </label>

        {error && <p className="error">{error}</p>}
        <div className="row end">
          <button className="btn ghost" onClick={onClose}>Close</button>
          <button className="btn" disabled={busy} onClick={submit}>{editing ? 'Save new time' : 'Confirm booking'}</button>
        </div>
      </div>
    </div>
  );
}
