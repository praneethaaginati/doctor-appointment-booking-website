import { Routes, Route, NavLink, Navigate, Link } from 'react-router-dom';
import { useAuth } from './AuthContext';
import Doctors from './pages/Doctors';
import Appointments from './pages/Appointments';
import Admin from './pages/Admin';
import Auth from './pages/Auth';

function Protected({ children, admin }) {
  const { user, loading } = useAuth();
  if (loading) return <p className="muted pad">Loading…</p>;
  if (!user) return <Navigate to="/login" replace />;
  if (admin && user.role !== 'admin') return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  const { user, logout } = useAuth();
  return (
    <>
      <header className="nav">
        <Link to="/" className="brand">CareSlot</Link>
        <nav>
          <NavLink to="/" end>Find a doctor</NavLink>
          {user && user.role === 'patient' && <NavLink to="/appointments">My appointments</NavLink>}
          {user?.role === 'admin' && <NavLink to="/admin">Manage clinic</NavLink>}
        </nav>
        <div className="nav-user">
          {user ? (
            <>
              <span className="muted">{user.name} ({user.role})</span>
              <button className="btn ghost" onClick={logout}>Log out</button>
            </>
          ) : (
            <Link className="btn" to="/login">Log in</Link>
          )}
        </div>
      </header>
      <main className="page">
        <Routes>
          <Route path="/" element={<Doctors />} />
          <Route path="/login" element={<Auth />} />
          <Route path="/appointments" element={<Protected><Appointments /></Protected>} />
          <Route path="/admin" element={<Protected admin><Admin /></Protected>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </>
  );
}
